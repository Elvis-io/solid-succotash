# Curtain Wall Tools v4 — pyRevit Extension

This pyRevit command finds curtain-wall `Wall` instances in the active Revit project, creates one wall-aligned orthographic section/elevation for each instance, documents the views, and arranges them on one or more sheets.

## New: architectural sheet-size optimizer

Version 4 adds an optional **Optimize viewport placement for the selected architectural sheet size (A0-A4)** setting.

The command now:

- Measures each loaded title-block type by temporarily creating a sheet and reading its actual sheet outline.
- Recognizes standard metric architectural sheet sizes by dimensions rather than by family or type name:
  - A0 — 841 × 1189 mm
  - A1 — 594 × 841 mm
  - A2 — 420 × 594 mm
  - A3 — 297 × 420 mm
  - A4 — 210 × 297 mm
- Detects portrait or landscape orientation automatically.
- Shows the detected size beside every title-block option in the settings window.
- Calculates the usable sheet rectangle from the actual width and height, sheet-edge margin, and bottom title-block reserve.
- Measures every viewport, including its view title where the Revit API supports it.
- Tests several best-fit rectangle-packing orders and selects the arrangement that uses the fewest sheets and makes the best use of the available area.
- Keeps viewports upright; it does not rotate curtain-wall elevations merely to make them fit.
- Creates continuation sheets when the selected scale produces more views than the selected sheet can contain.
- Reports the detected sheet size, usable layout area, placement method, and viewport-area utilization for every sheet.

The optimizer is deliberately limited to measured A0-A4 title blocks. A custom or non-A-series title block can still be used by disabling the optimizer; the command then uses the standard row-layout method.

### A3 example

For a landscape A3 title block measured at 420 × 297 mm, using:

- Sheet edge margin: 15 mm
- Bottom reserved area: 35 mm

produces a calculated viewport layout area of:

```text
390 × 247 mm
```

The add-in packs the measured viewport rectangles into that area and creates additional A3 sheets when necessary.

## Other included functionality

- Editable **Drawing scale** selector with standard architectural ratios and custom whole-number denominators.
- View naming by curtain-wall type, with sequence numbers for repeated types.
- Optional chained dimensions to curtain grid lines.
- Optional overall curtain-wall width and height dimensions.
- Fallback value notes and a review report where native Revit references cannot support a requested dimension.
- Automatic continuation-sheet numbering, for example `CW-001`, `CW-002`, and `CW-003`.
- Automatic scale adjustment only when an individual viewport is too large for the usable sheet area and the Auto-adjust option is enabled.
- Optional opening of the first generated sheet after completion.

## Requirements

- Autodesk Revit 2022–2026
- A pyRevit installation compatible with the installed Revit version
- At least one loaded Revit title-block type
- At least one Section view type
- A Revit project document; the command does not run in the Family Editor

The command uses pyRevit's default IronPython engine because the settings window is built with pyRevit WPF forms. Do not add a CPython/Python 3 shebang to `script.py`.

## Installation

### Automatic installation

1. Extract the ZIP package to a normal Windows folder.
2. Double-click `Install_CurtainWallTools.bat`.
3. Open Revit and use **pyRevit > Reload**, or restart Revit.

The installer copies the extension to:

```text
%APPDATA%\pyRevit\Extensions\CurtainWallTools.extension
```

The installer uses `/PURGE`, so installing this package over an older version replaces the old command files.

### Manual installation

Copy the entire folder:

```text
CurtainWallTools.extension
```

into:

```text
%APPDATA%\pyRevit\Extensions\
```

The final path should be:

```text
%APPDATA%\pyRevit\Extensions\CurtainWallTools.extension
```

Reload pyRevit or restart Revit.

## Ribbon location

```text
Curtain Wall Tools > Documentation > Curtain Wall Sheets
```

## How to use

1. Open the Revit project containing the curtain walls and save a backup.
2. Open **Curtain Wall Tools > Documentation > Curtain Wall Sheets**.
3. Select a title block. Its detected sheet size and orientation appear immediately below the selector.
4. Leave **Optimize viewport placement for the selected architectural sheet size (A0-A4)** enabled when using A0, A1, A2, A3, or A4.
5. For a custom or non-A-series title block, disable the optimizer and use the standard layout method.
6. Select the Section view type and the exterior or interior wall face.
7. Enter the first sheet number and base sheet name.
8. Select the required **Drawing scale**. Accepted examples include `50`, `1:50`, `1 : 50`, and `1/50`.
9. Enable or disable view naming and dimension options as required.
10. Enter the crop margin, viewport gap, sheet-edge margin, bottom reserved area, and dimension-line spacing.
11. Leave **Place overflow views on continuation sheets** enabled when the first sheet may become crowded.
12. Leave **Auto-adjust to a smaller drawing size only when a viewport is too large** enabled when an individual elevation may need to change from, for example, `1:50` to `1:75`.
13. Click **Create Views + Sheets**.

## Scale and continuation-sheet behaviour

The selected drawing scale is applied before viewport measurement and placement.

When continuation sheets are enabled:

1. The command first tries the exact selected scale.
2. If every individual viewport fits the usable sheet rectangle, the selected scale is retained and the optimizer distributes the views across as many sheets as required.
3. If one individual viewport is larger than the usable sheet rectangle, the Auto-adjust option tries progressively larger scale denominators until that viewport fits.
4. If Auto-adjust is disabled, the selected scale is locked and any oversized result is reported for review.

For a base number of `CW-001`, continuation sheets normally become:

```text
CW-001
CW-002
CW-003
```

If a proposed number already exists, the add-in creates a unique variation. Multi-sheet names are formatted as:

```text
CURTAIN WALL ELEVATIONS - 1 OF 3
CURTAIN WALL ELEVATIONS - 2 OF 3
CURTAIN WALL ELEVATIONS - 3 OF 3
```

## Dimension behaviour

The command attempts to create native Revit linear dimensions with geometric references:

- Vertical curtain-grid lines form the horizontal bay-width chain.
- Horizontal curtain-grid lines form the vertical bay-height chain.
- Wall endpoints and extreme model faces are used for overall width and height.
- The current Revit default linear dimension style is used.

Curtain-wall geometry varies between families and project configurations. When valid references cannot be bound, the command retains the view, adds a value note where possible, and lists the affected wall in the pyRevit output under **Dimensioning Review**. Curved curtain walls receive projected overall values and require manual review for developed or radial dimensions.

## Result report

The pyRevit output lists:

- Created sheets and the number of views on each
- Detected sheet size and orientation
- Actual usable layout area after margins and bottom reserve
- Placement method used
- Viewport-area utilization for each sheet
- Selected and final drawing scales
- Curtain-grid and overall dimensions created
- Fallback value notes
- Dimensioning warnings requiring review
- Curtain walls skipped because a view could not be created

## Scope and limitations

- Processes curtain-wall `Wall` instances in the active project only.
- Does not process Revit links.
- Does not process mass-based `CurtainSystem` elements.
- The architectural optimizer accepts measured A0-A4 title blocks only.
- Viewports are not rotated by the optimizer.
- Curved curtain walls are orthographically projected; they are not developed or unrolled.
- The bottom reserved area remains a full-width protected band; adjust it to suit the selected title block's information panel.
- Every execution creates a new set of views and sheets. It does not update a previous run.
- Generated section/elevation references may be visible in applicable model views, depending on project visibility settings.
- Native dimensions depend on usable Revit geometric references. Review the **Dimensioning Review** table after each run.

## Uninstallation

Double-click:

```text
Uninstall_CurtainWallTools.bat
```

Then reload pyRevit or restart Revit.

## Package structure

```text
CurtainWallTools.extension/
└── Curtain Wall Tools.tab/
    └── Documentation.panel/
        └── Create Curtain Wall Sheet.pushbutton/
            ├── bundle.yaml
            ├── icon.png
            ├── icon.dark.png
            ├── script.py
            └── ui.xaml
```

## Validation status

The package has been checked for Python syntax, IronPython-compatible language features, A-series size matching, A3 portrait/landscape recognition, best-fit sheet packing, scale parsing, XAML/XML validity, WPF control/event matching, command metadata, icons, installer line endings, required package files, and ZIP integrity.

Static validation cannot reproduce Revit's model-specific geometry or title-block family behaviour. Run the first test on a copy of the project and review the generated dimensions, crop regions, title-block reserve, and continuation-sheet layouts before issuing drawings.
