# -*- coding: utf-8 -*-
"""Create documented curtain-wall elevations and arrange them on sheets.

Designed as a pyRevit push-button command for Revit 2022-2026.
The command uses pyRevit's default IronPython engine because its user interface
is built with pyRevit WPF forms.
"""
from __future__ import print_function

import os
import re
import traceback

from pyrevit import DB
from pyrevit import forms
from pyrevit import revit
from pyrevit import script

try:
    from System.Windows.Controls import ComboBoxItem
except Exception:
    ComboBoxItem = None


__title__ = "Curtain Wall\nSheets"
__author__ = "OpenAI for Elvis Ekwegbo"
__doc__ = (
    "Creates type-named, wall-aligned curtain-wall elevations at a selected "
    "drawing scale, optionally adds curtain-grid and overall dimensions, and "
    "automatically places the views across one or more sheets."
)


doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()
logger = script.get_logger()
config = script.get_config()
XAML_PATH = os.path.join(os.path.dirname(__file__), "ui.xaml")

# Common metric architectural scales shown in the settings dialog. The scale
# ComboBox remains editable, so any positive whole-number denominator can also
# be entered (for example 1:40 or 1:60).
STANDARD_DRAWING_SCALES = [
    5, 10, 20, 25, 40, 50, 75, 100, 125, 150, 200, 250, 300,
    400, 500, 750, 1000, 1500, 2000, 2500, 5000, 10000, 15000, 24000,
]


# -----------------------------------------------------------------------------
# General helpers
# -----------------------------------------------------------------------------

def config_value(name, default):
    try:
        return getattr(config, name)
    except Exception:
        return default


def to_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    if text in ("true", "1", "yes", "on"):
        return True
    if text in ("false", "0", "no", "off"):
        return False
    return default


def mm(value):
    """Convert millimetres to Revit internal units."""
    try:
        return DB.UnitUtils.ConvertToInternalUnits(
            float(value), DB.UnitTypeId.Millimeters
        )
    except AttributeError:
        return DB.UnitUtils.ConvertToInternalUnits(
            float(value), DB.DisplayUnitType.DUT_MILLIMETERS
        )


def from_internal_mm(value):
    try:
        return DB.UnitUtils.ConvertFromInternalUnits(
            float(value), DB.UnitTypeId.Millimeters
        )
    except AttributeError:
        return DB.UnitUtils.ConvertFromInternalUnits(
            float(value), DB.DisplayUnitType.DUT_MILLIMETERS
        )


def format_length(value):
    """Format a model length using project units, with a metric fallback."""
    try:
        return DB.UnitFormatUtils.Format(
            doc.GetUnits(), DB.SpecTypeId.Length, float(value), False
        )
    except Exception:
        value_mm = from_internal_mm(value)
        if abs(value_mm - round(value_mm)) < 0.01:
            return "{0:.0f} mm".format(value_mm)
        return "{0:.1f} mm".format(value_mm)


def id_number(element_or_id):
    element_id = getattr(element_or_id, "Id", element_or_id)
    try:
        return int(element_id.Value)
    except Exception:
        return int(element_id.IntegerValue)


def element_type_name(element):
    """Return a stable display name for a Revit ElementType."""
    try:
        parameter = element.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        if parameter:
            value = parameter.AsString()
            if value:
                return value
    except Exception:
        pass

    try:
        value = element.Name
        if value:
            return value
    except Exception:
        pass

    return "Type {0}".format(id_number(element))


def title_block_label(symbol):
    try:
        family_name = symbol.FamilyName
    except Exception:
        try:
            family_name = symbol.Family.Name
        except Exception:
            family_name = "Title Block"
    return "{0} : {1}".format(family_name, element_type_name(symbol))


def clean_name(value):
    text = str(value or "")
    invalid_characters = [
        "\\", ":", "{", "}", "[", "]", "|", ";", "<", ">", "?", "`", "~"
    ]
    for character in invalid_characters:
        text = text.replace(character, "-")
    return " ".join(text.split()).strip()


def all_sheet_numbers():
    numbers = set()
    for sheet in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet):
        try:
            numbers.add(sheet.SheetNumber.lower())
        except Exception:
            pass
    return numbers


def reserve_unique_sheet_number(desired_number, used_numbers):
    base_number = clean_name(desired_number) or "CW-001"
    candidate = base_number
    suffix = 1
    while candidate.lower() in used_numbers:
        candidate = "{0}.{1:02d}".format(base_number, suffix)
        suffix += 1
    used_numbers.add(candidate.lower())
    return candidate


def sheet_series_candidate(base_number, page_index):
    """Return a human-friendly continuation number for a zero-based page."""
    base_number = clean_name(base_number) or "CW-001"
    if page_index <= 0:
        return base_number

    match = re.match(r"^(.*?)(\d+)$", base_number)
    if match:
        prefix = match.group(1)
        digits = match.group(2)
        next_number = str(int(digits) + page_index).zfill(len(digits))
        return "{0}{1}".format(prefix, next_number)
    return "{0}-{1:02d}".format(base_number, page_index + 1)


def unique_view_name(base_name, used_names):
    cleaned_base = clean_name(base_name) or "CURTAIN WALL ELEVATION"
    cleaned_base = cleaned_base[:230].rstrip()
    candidate = cleaned_base
    suffix = 1
    while candidate.lower() in used_names:
        suffix += 1
        suffix_text = " ({0})".format(suffix)
        candidate = cleaned_base[:230 - len(suffix_text)].rstrip() + suffix_text
    used_names.add(candidate.lower())
    return candidate


def vector_dot(first, second):
    return (
        first.X * second.X
        + first.Y * second.Y
        + first.Z * second.Z
    )


def projected_coordinate(point, origin, axis):
    return vector_dot(point - origin, axis)


def reference_key(reference):
    try:
        return reference.ConvertToStableRepresentation(doc)
    except Exception:
        try:
            return "E{0}-T{1}".format(
                id_number(reference.ElementId),
                int(reference.ElementReferenceType),
            )
        except Exception:
            return str(reference)


def collect_curtain_walls():
    walls = []
    collector = (
        DB.FilteredElementCollector(doc)
        .OfClass(DB.Wall)
        .WhereElementIsNotElementType()
    )
    for wall in collector:
        try:
            if wall.WallType.Kind == DB.WallKind.Curtain:
                walls.append(wall)
        except Exception:
            continue
    walls.sort(
        key=lambda item: (
            element_type_name(item.WallType).lower(),
            id_number(item),
        )
    )
    return walls


def collect_title_blocks():
    symbols = list(
        DB.FilteredElementCollector(doc)
        .OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
        .WhereElementIsElementType()
    )
    symbols.sort(key=lambda item: title_block_label(item).lower())
    return symbols


def collect_section_types():
    result = []
    for view_type in DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType):
        try:
            if view_type.ViewFamily == DB.ViewFamily.Section:
                result.append(view_type)
        except Exception:
            continue
    result.sort(key=lambda item: element_type_name(item).lower())
    return result


def collect_text_note_type_id():
    try:
        text_type = (
            DB.FilteredElementCollector(doc)
            .OfClass(DB.TextNoteType)
            .FirstElement()
        )
        if text_type:
            return text_type.Id
    except Exception:
        pass
    return DB.ElementId.InvalidElementId


def all_used_view_names():
    used = set()
    for view in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            used.add(view.Name.lower())
        except Exception:
            pass
    return used


def view_name_data(walls):
    totals = {}
    counters = {}
    data = {}

    for wall in walls:
        type_name = clean_name(element_type_name(wall.WallType)) or "Curtain Wall"
        key = type_name.lower()
        totals[key] = totals.get(key, 0) + 1

    for wall in walls:
        type_name = clean_name(element_type_name(wall.WallType)) or "Curtain Wall"
        key = type_name.lower()
        counters[key] = counters.get(key, 0) + 1
        data[id_number(wall)] = {
            "type_name": type_name,
            "sequence": counters[key],
            "total": totals[key],
        }
    return data


# -----------------------------------------------------------------------------
# Settings window
# -----------------------------------------------------------------------------

def add_combo_item(combo, label, value):
    if ComboBoxItem is None:
        raise RuntimeError("WPF ComboBoxItem could not be loaded.")
    item = ComboBoxItem()
    item.Content = label
    item.Tag = value
    combo.Items.Add(item)
    return item


def select_combo_label(combo, label):
    wanted = str(label or "")
    for item in combo.Items:
        try:
            if str(item.Content) == wanted:
                combo.SelectedItem = item
                return True
        except Exception:
            pass
    return False


def drawing_scale_label(scale):
    return "1 : {0}".format(int(scale))


def populate_drawing_scale_combo(combo, saved_scale):
    combo.Items.Clear()
    combo.SelectedItem = None
    for scale in STANDARD_DRAWING_SCALES:
        # Strings are used here instead of ComboBoxItem objects so the editable
        # text value is always the visible ratio and can be parsed reliably.
        combo.Items.Add(drawing_scale_label(scale))

    try:
        saved_value = parse_drawing_scale(saved_scale)
    except Exception:
        saved_value = 50

    saved_label = drawing_scale_label(saved_value)
    for index in range(combo.Items.Count):
        try:
            if str(combo.Items[index]) == saved_label:
                combo.SelectedIndex = index
                combo.Text = saved_label
                return
        except Exception:
            pass

    # Retain a previously entered custom denominator that is not in the list.
    combo.SelectedItem = None
    combo.Text = saved_label


def parse_drawing_scale(value):
    """Return a positive whole-number scale denominator from common formats."""
    text = str(value or "").strip().lower()
    text = text.replace("scale", "").replace(" ", "")
    if not text:
        raise ValueError("Select or enter a drawing scale.")

    if ":" in text:
        text = text.rsplit(":", 1)[-1]
    elif "/" in text:
        parts = text.rsplit("/", 1)
        text = parts[-1]

    text = text.replace(",", ".")
    try:
        number = float(text)
    except Exception:
        raise ValueError(
            "Drawing scale must be entered as a denominator such as 50 or 1:50."
        )

    rounded = int(round(number))
    if rounded < 1:
        raise ValueError("Drawing scale must be at least 1:1.")
    if abs(number - rounded) > 0.000001:
        raise ValueError("Drawing scale denominator must be a whole number.")
    return rounded


class CurtainWallSettingsWindow(forms.WPFWindow):
    def __init__(self, title_blocks, section_types, wall_count):
        forms.WPFWindow.__init__(self, XAML_PATH)
        self.result = None

        self.wall_count_text.Text = (
            "{0} curtain-wall instance{1} found in the active project."
            .format(wall_count, "" if wall_count == 1 else "s")
        )

        saved_title_block = config_value("title_block_label", "")
        for symbol in title_blocks:
            add_combo_item(
                self.title_block_combo,
                title_block_label(symbol),
                symbol,
            )
        if not select_combo_label(self.title_block_combo, saved_title_block):
            self.title_block_combo.SelectedIndex = 0

        saved_section_type = config_value("section_type_label", "")
        for section_type in section_types:
            add_combo_item(
                self.section_type_combo,
                element_type_name(section_type),
                section_type,
            )
        if not select_combo_label(self.section_type_combo, saved_section_type):
            self.section_type_combo.SelectedIndex = 0

        exterior_item = add_combo_item(
            self.direction_combo,
            "Exterior face (default)",
            "Exterior",
        )
        interior_item = add_combo_item(
            self.direction_combo,
            "Interior face",
            "Interior",
        )
        saved_direction = str(config_value("view_side", "Exterior"))
        self.direction_combo.SelectedItem = (
            interior_item if saved_direction == "Interior" else exterior_item
        )

        self.sheet_number_text.Text = str(
            config_value("sheet_number", "CW-001")
        )
        self.sheet_name_text.Text = str(
            config_value("sheet_name", "CURTAIN WALL ELEVATIONS")
        )
        saved_scale = config_value(
            "drawing_scale",
            config_value("start_scale", "50"),
        )
        populate_drawing_scale_combo(self.scale_combo, saved_scale)
        self.crop_margin_text.Text = str(
            config_value("crop_margin_mm", "300")
        )
        self.viewport_gap_text.Text = str(
            config_value("viewport_gap_mm", "10")
        )
        self.sheet_margin_text.Text = str(
            config_value("sheet_margin_mm", "15")
        )
        self.bottom_reserve_text.Text = str(
            config_value("bottom_reserve_mm", "35")
        )
        self.dimension_spacing_text.Text = str(
            config_value("dimension_spacing_mm", "300")
        )

        self.name_by_type_check.IsChecked = to_bool(
            config_value("name_by_type", True), True
        )
        self.dimension_grids_check.IsChecked = to_bool(
            config_value("dimension_grids", True), True
        )
        self.dimension_overall_check.IsChecked = to_bool(
            config_value("dimension_overall", True), True
        )
        self.multiple_sheets_check.IsChecked = to_bool(
            config_value("multiple_sheets", True), True
        )
        self.auto_fit_check.IsChecked = to_bool(
            config_value("auto_fit", True), True
        )
        self.open_sheet_check.IsChecked = to_bool(
            config_value("open_sheet", True), True
        )

        self.create_button.Content = "Create {0} View{1} + Sheet{2}".format(
            wall_count,
            "" if wall_count == 1 else "s",
            "" if wall_count == 1 else "s",
        )

    def _set_error(self, message):
        self.status_text.Text = message

    def _parse_number(self, control, field_name, minimum, integer=False):
        raw_value = str(control.Text or "").strip().replace(",", ".")
        try:
            value = float(raw_value)
        except Exception:
            raise ValueError("{0} must be a number.".format(field_name))

        if value < minimum:
            raise ValueError(
                "{0} must be at least {1}.".format(field_name, minimum)
            )

        if integer:
            rounded = int(round(value))
            if abs(value - rounded) > 0.000001:
                raise ValueError("{0} must be a whole number.".format(field_name))
            return rounded
        return value

    def _selected_drawing_scale(self):
        text = str(self.scale_combo.Text or "").strip()
        if not text and self.scale_combo.SelectedItem is not None:
            text = str(self.scale_combo.SelectedItem)
        return parse_drawing_scale(text)

    def create_click(self, sender, args):
        try:
            sheet_number = clean_name(self.sheet_number_text.Text)
            sheet_name = clean_name(self.sheet_name_text.Text)
            if not sheet_number:
                raise ValueError("Enter a sheet number.")
            if not sheet_name:
                raise ValueError("Enter a sheet name.")
            if self.title_block_combo.SelectedItem is None:
                raise ValueError("Select a title-block type.")
            if self.section_type_combo.SelectedItem is None:
                raise ValueError("Select a section view type.")
            if self.direction_combo.SelectedItem is None:
                raise ValueError("Select the elevation face.")

            self.result = {
                "title_block": self.title_block_combo.SelectedItem.Tag,
                "title_block_label": str(
                    self.title_block_combo.SelectedItem.Content
                ),
                "section_type": self.section_type_combo.SelectedItem.Tag,
                "section_type_label": str(
                    self.section_type_combo.SelectedItem.Content
                ),
                "view_side": str(self.direction_combo.SelectedItem.Tag),
                "sheet_number": sheet_number,
                "sheet_name": sheet_name,
                "start_scale": self._selected_drawing_scale(),
                "crop_margin_mm": self._parse_number(
                    self.crop_margin_text, "Crop margin", 0
                ),
                "viewport_gap_mm": self._parse_number(
                    self.viewport_gap_text, "Viewport gap", 0
                ),
                "sheet_margin_mm": self._parse_number(
                    self.sheet_margin_text, "Sheet edge margin", 0
                ),
                "bottom_reserve_mm": self._parse_number(
                    self.bottom_reserve_text, "Bottom reserved area", 0
                ),
                "dimension_spacing_mm": self._parse_number(
                    self.dimension_spacing_text, "Dimension line spacing", 1
                ),
                "name_by_type": to_bool(
                    self.name_by_type_check.IsChecked, True
                ),
                "dimension_grids": to_bool(
                    self.dimension_grids_check.IsChecked, True
                ),
                "dimension_overall": to_bool(
                    self.dimension_overall_check.IsChecked, True
                ),
                "multiple_sheets": to_bool(
                    self.multiple_sheets_check.IsChecked, True
                ),
                "auto_fit": to_bool(self.auto_fit_check.IsChecked, True),
                "open_sheet": to_bool(self.open_sheet_check.IsChecked, True),
            }
            self.Close()
        except ValueError as error:
            self._set_error(str(error))
        except Exception as error:
            self._set_error("Invalid settings: {0}".format(error))

    def reset_click(self, sender, args):
        self.sheet_number_text.Text = "CW-001"
        self.sheet_name_text.Text = "CURTAIN WALL ELEVATIONS"
        populate_drawing_scale_combo(self.scale_combo, 50)
        self.crop_margin_text.Text = "300"
        self.viewport_gap_text.Text = "10"
        self.sheet_margin_text.Text = "15"
        self.bottom_reserve_text.Text = "35"
        self.dimension_spacing_text.Text = "300"
        self.name_by_type_check.IsChecked = True
        self.dimension_grids_check.IsChecked = True
        self.dimension_overall_check.IsChecked = True
        self.multiple_sheets_check.IsChecked = True
        self.auto_fit_check.IsChecked = True
        self.open_sheet_check.IsChecked = True
        if self.direction_combo.Items.Count:
            self.direction_combo.SelectedIndex = 0
        self.status_text.Text = "Defaults restored."

    def cancel_click(self, sender, args):
        self.result = None
        self.Close()


def save_settings(settings):
    try:
        config.title_block_label = settings["title_block_label"]
        config.section_type_label = settings["section_type_label"]
        config.view_side = settings["view_side"]
        config.sheet_number = settings["sheet_number"]
        config.sheet_name = settings["sheet_name"]
        config.drawing_scale = str(settings["start_scale"])
        # Retain the legacy key so settings survive upgrades from v2.
        config.start_scale = str(settings["start_scale"])
        config.crop_margin_mm = str(settings["crop_margin_mm"])
        config.viewport_gap_mm = str(settings["viewport_gap_mm"])
        config.sheet_margin_mm = str(settings["sheet_margin_mm"])
        config.bottom_reserve_mm = str(settings["bottom_reserve_mm"])
        config.dimension_spacing_mm = str(settings["dimension_spacing_mm"])
        config.name_by_type = bool(settings["name_by_type"])
        config.dimension_grids = bool(settings["dimension_grids"])
        config.dimension_overall = bool(settings["dimension_overall"])
        config.multiple_sheets = bool(settings["multiple_sheets"])
        config.auto_fit = bool(settings["auto_fit"])
        config.open_sheet = bool(settings["open_sheet"])
        script.save_config()
    except Exception as error:
        logger.warning("Could not save command settings: %s", error)


# -----------------------------------------------------------------------------
# Curtain-wall view geometry
# -----------------------------------------------------------------------------

def model_bbox_corners(box):
    points = []
    for x_value in (box.Min.X, box.Max.X):
        for y_value in (box.Min.Y, box.Max.Y):
            for z_value in (box.Min.Z, box.Max.Z):
                points.append(
                    box.Transform.OfPoint(DB.XYZ(x_value, y_value, z_value))
                )
    return points


def curtain_wall_section_frame(
    wall,
    crop_margin,
    depth_margin,
    view_side,
):
    box = wall.get_BoundingBox(None)
    if box is None:
        raise RuntimeError("The wall has no model bounding box.")

    points = model_bbox_corners(box)

    # Wall.Orientation points toward the wall exterior. For an exterior-face
    # elevation, reverse the direction so the section looks toward the wall.
    normal = wall.Orientation
    normal = DB.XYZ(normal.X, normal.Y, 0.0)
    if normal.GetLength() < 0.000000001:
        raise RuntimeError("A horizontal wall orientation could not be determined.")

    if view_side == "Interior":
        view_direction = normal.Normalize()
    else:
        view_direction = normal.Normalize().Negate()

    up_direction = DB.XYZ.BasisZ
    right_direction = up_direction.CrossProduct(view_direction).Normalize()

    point_count = float(len(points))
    origin = DB.XYZ(
        sum(point.X for point in points) / point_count,
        sum(point.Y for point in points) / point_count,
        sum(point.Z for point in points) / point_count,
    )

    transform = DB.Transform.Identity
    transform.Origin = origin
    transform.BasisX = right_direction
    transform.BasisY = up_direction
    transform.BasisZ = view_direction

    inverse = transform.Inverse
    local_points = [inverse.OfPoint(point) for point in points]

    model_min_x = min(point.X for point in local_points)
    model_max_x = max(point.X for point in local_points)
    model_min_y = min(point.Y for point in local_points)
    model_max_y = max(point.Y for point in local_points)
    model_min_z = min(point.Z for point in local_points)
    model_max_z = max(point.Z for point in local_points)

    section_box = DB.BoundingBoxXYZ()
    section_box.Transform = transform
    section_box.Min = DB.XYZ(
        model_min_x - crop_margin,
        model_min_y - crop_margin,
        model_min_z - depth_margin,
    )
    section_box.Max = DB.XYZ(
        model_max_x + crop_margin,
        model_max_y + crop_margin,
        model_max_z + depth_margin,
    )

    return {
        "box": section_box,
        "transform": transform,
        "origin": origin,
        "right": right_direction,
        "up": up_direction,
        "view_direction": view_direction,
        "model_min_x": model_min_x,
        "model_max_x": model_max_x,
        "model_min_y": model_min_y,
        "model_max_y": model_max_y,
        "model_min_z": model_min_z,
        "model_max_z": model_max_z,
    }


def frame_point(frame, x_value, y_value, z_value=0.0):
    return frame["transform"].OfPoint(
        DB.XYZ(float(x_value), float(y_value), float(z_value))
    )


def wall_is_straight(wall):
    try:
        return isinstance(wall.Location.Curve, DB.Line)
    except Exception:
        return False


# -----------------------------------------------------------------------------
# Dimension reference extraction
# -----------------------------------------------------------------------------

def geometry_options(view):
    options = DB.Options()
    options.ComputeReferences = True
    options.IncludeNonVisibleObjects = True
    try:
        options.View = view
    except Exception:
        try:
            options.DetailLevel = DB.ViewDetailLevel.Fine
        except Exception:
            pass
    return options


def iter_planar_faces(geometry_element, current_transform):
    if geometry_element is None:
        return

    for geometry_object in geometry_element:
        if isinstance(geometry_object, DB.Solid):
            try:
                if geometry_object.Faces.Size == 0:
                    continue
            except Exception:
                continue
            for face in geometry_object.Faces:
                if isinstance(face, DB.PlanarFace):
                    yield face, current_transform

        elif isinstance(geometry_object, DB.GeometryInstance):
            nested_transform = current_transform
            try:
                nested_transform = current_transform.Multiply(
                    geometry_object.Transform
                )
            except Exception:
                pass

            nested_geometry = None
            try:
                nested_geometry = geometry_object.GetSymbolGeometry()
            except Exception:
                try:
                    nested_geometry = geometry_object.GetInstanceGeometry()
                    nested_transform = current_transform
                except Exception:
                    nested_geometry = None

            if nested_geometry is not None:
                for item in iter_planar_faces(
                    nested_geometry,
                    nested_transform,
                ):
                    yield item


def curtain_reference_elements(wall):
    elements = [wall]
    seen = set([id_number(wall)])

    try:
        curtain_grid = wall.CurtainGrid
        child_ids = []
        child_ids.extend(list(curtain_grid.GetPanelIds()))
        child_ids.extend(list(curtain_grid.GetMullionIds()))
        for element_id in child_ids:
            number = id_number(element_id)
            if number in seen:
                continue
            element = doc.GetElement(element_id)
            if element is not None:
                elements.append(element)
                seen.add(number)
    except Exception:
        pass

    return elements


def planar_face_reference_data(wall, view):
    """Parse referenceable planar faces once for both overall dimensions."""
    result = []
    options = geometry_options(view)

    for element in curtain_reference_elements(wall):
        try:
            geometry = element.get_Geometry(options)
        except Exception:
            geometry = None
        if geometry is None:
            continue

        for face, face_transform in iter_planar_faces(
            geometry,
            DB.Transform.Identity,
        ):
            try:
                reference = face.Reference
                if reference is None:
                    continue
                normal = face_transform.OfVector(face.FaceNormal)
                if normal.GetLength() < 0.000000001:
                    continue
                normal = normal.Normalize()
                origin = face_transform.OfPoint(face.Origin)
                result.append((origin, normal, reference))
            except Exception:
                continue

    return result


def extreme_face_entries(face_data, frame, axis):
    candidates = []
    for origin, normal, reference in face_data:
        try:
            if abs(vector_dot(normal, axis)) < 0.965:
                continue
            coordinate = projected_coordinate(
                origin,
                frame["origin"],
                axis,
            )
            candidates.append((coordinate, reference))
        except Exception:
            continue

    if len(candidates) < 2:
        return []

    candidates.sort(key=lambda item: item[0])
    return [candidates[0], candidates[-1]]


def wall_endpoint_entries(wall, frame):
    result = []
    try:
        curve = wall.Location.Curve
        if not isinstance(curve, DB.Line):
            return []
        for index in (0, 1):
            reference = curve.GetEndPointReference(index)
            point = curve.GetEndPoint(index)
            if reference is not None:
                result.append(
                    (
                        projected_coordinate(
                            point,
                            frame["origin"],
                            frame["right"],
                        ),
                        reference,
                    )
                )
    except Exception:
        return []

    result.sort(key=lambda item: item[0])
    return result


def grid_curve_reference(grid_line):
    try:
        curve = grid_line.FullCurve
        reference = curve.Reference
        if reference is not None:
            return reference
    except Exception:
        pass
    return None


def grid_element_reference(grid_line):
    try:
        return DB.Reference(grid_line)
    except Exception:
        return None


def collect_grid_line_data(wall, frame):
    vertical = []
    horizontal = []

    try:
        curtain_grid = wall.CurtainGrid
        grid_ids = []
        grid_ids.extend(list(curtain_grid.GetUGridLineIds()))
        grid_ids.extend(list(curtain_grid.GetVGridLineIds()))
    except Exception:
        return vertical, horizontal

    seen_ids = set()
    for grid_id in grid_ids:
        number = id_number(grid_id)
        if number in seen_ids:
            continue
        seen_ids.add(number)

        grid_line = doc.GetElement(grid_id)
        if grid_line is None:
            continue

        try:
            curve = grid_line.FullCurve
            first = curve.GetEndPoint(0)
            second = curve.GetEndPoint(1)
            direction = second - first
            if direction.GetLength() < 0.000000001:
                continue
            direction = direction.Normalize()
            midpoint = (first + second) * 0.5
        except Exception:
            continue

        primary_reference = grid_curve_reference(grid_line)
        alternate_reference = grid_element_reference(grid_line)
        if primary_reference is None and alternate_reference is None:
            continue

        vertical_score = abs(vector_dot(direction, frame["up"]))
        horizontal_score = abs(vector_dot(direction, frame["right"]))

        item = {
            "element": grid_line,
            "primary": primary_reference,
            "alternate": alternate_reference,
        }

        if vertical_score >= horizontal_score and vertical_score > 0.70:
            item["coordinate"] = projected_coordinate(
                midpoint,
                frame["origin"],
                frame["right"],
            )
            vertical.append(item)
        elif horizontal_score > vertical_score and horizontal_score > 0.70:
            item["coordinate"] = projected_coordinate(
                midpoint,
                frame["origin"],
                frame["up"],
            )
            horizontal.append(item)

    vertical.sort(key=lambda item: item["coordinate"])
    horizontal.sort(key=lambda item: item["coordinate"])
    return vertical, horizontal


def clean_dimension_entries(entries, coordinate_tolerance=0.00001):
    cleaned = []
    reference_keys = set()

    for coordinate, reference in sorted(entries, key=lambda item: item[0]):
        if reference is None:
            continue
        key = reference_key(reference)
        if key in reference_keys:
            continue
        if cleaned and abs(coordinate - cleaned[-1][0]) < coordinate_tolerance:
            continue
        cleaned.append((coordinate, reference))
        reference_keys.add(key)

    return cleaned


def try_create_dimension(view, dimension_line, entries):
    entries = clean_dimension_entries(entries)
    if len(entries) < 2:
        return None, "Fewer than two usable references were found."

    references = DB.ReferenceArray()
    for coordinate, reference in entries:
        references.Append(reference)

    subtransaction = DB.SubTransaction(doc)
    subtransaction.Start()
    try:
        dimension = doc.Create.NewDimension(
            view,
            dimension_line,
            references,
        )
        if dimension is None:
            raise RuntimeError("Revit returned no Dimension element.")
        subtransaction.Commit()
        return dimension, None
    except Exception as error:
        try:
            subtransaction.RollBack()
        except Exception:
            pass
        return None, str(error)


def first_successful_dimension(view, dimension_line, entry_variants):
    errors = []
    attempted_keys = set()

    for entries in entry_variants:
        cleaned = clean_dimension_entries(entries)
        if len(cleaned) < 2:
            continue
        signature = tuple(reference_key(item[1]) for item in cleaned)
        if signature in attempted_keys:
            continue
        attempted_keys.add(signature)

        dimension, error = try_create_dimension(
            view,
            dimension_line,
            cleaned,
        )
        if dimension is not None:
            return dimension, None
        if error:
            errors.append(error)

    if errors:
        return None, errors[-1]
    return None, "No valid reference set was available."


def grid_entries(grid_items, reference_field):
    result = []
    for item in grid_items:
        reference = item.get(reference_field)
        if reference is not None:
            result.append((item["coordinate"], reference))
    return result


def build_grid_entry_variants(grid_items, boundary_variants):
    variants = []
    for reference_field in ("primary", "alternate"):
        grids = grid_entries(grid_items, reference_field)
        if not grids:
            continue
        for boundaries in boundary_variants:
            if boundaries:
                variants.append(boundaries + grids)
        variants.append(grids)
    return variants


def try_create_text_note(view, point, text, text_type_id):
    if text_type_id == DB.ElementId.InvalidElementId:
        return None, "No TextNoteType is available for fallback notes."

    subtransaction = DB.SubTransaction(doc)
    subtransaction.Start()
    try:
        options = DB.TextNoteOptions(text_type_id)
        try:
            options.HorizontalAlignment = DB.HorizontalTextAlignment.Left
        except Exception:
            pass
        note = DB.TextNote.Create(
            doc,
            view.Id,
            point,
            0.0,
            text,
            options,
        )
        subtransaction.Commit()
        return note, None
    except Exception as error:
        try:
            subtransaction.RollBack()
        except Exception:
            pass
        return None, str(error)


def interval_text(coordinates):
    sorted_values = sorted(coordinates)
    cleaned = []
    for value in sorted_values:
        if not cleaned or abs(value - cleaned[-1]) > 0.00001:
            cleaned.append(value)
    if len(cleaned) < 2:
        return ""
    return " + ".join(
        format_length(cleaned[index + 1] - cleaned[index])
        for index in range(len(cleaned) - 1)
    )


def annotate_curtain_wall(
    wall,
    view,
    frame,
    settings,
    text_type_id,
):
    result = {
        "overall_dimensions": 0,
        "grid_dimensions": 0,
        "fallback_notes": 0,
        "warnings": [],
    }

    if not settings["dimension_overall"] and not settings["dimension_grids"]:
        return result

    spacing = mm(settings["dimension_spacing_mm"])
    min_x = frame["model_min_x"]
    max_x = frame["model_max_x"]
    min_y = frame["model_min_y"]
    max_y = frame["model_max_y"]

    width = max_x - min_x
    height = max_y - min_y
    fallback_lines = []

    if not wall_is_straight(wall):
        if settings["dimension_overall"]:
            fallback_lines.append(
                "PROJECTED OVERALL WIDTH: {0}".format(format_length(width))
            )
            fallback_lines.append(
                "PROJECTED OVERALL HEIGHT: {0}".format(format_length(height))
            )
        if settings["dimension_grids"]:
            fallback_lines.append(
                "CURVED WALL: GRID CHAIN DIMENSIONS REQUIRE MANUAL REVIEW"
            )
        result["warnings"].append(
            "Curved curtain wall: projected values were used; graphical grid dimensions were skipped."
        )
    else:
        width_boundaries = []
        endpoint_entries = wall_endpoint_entries(wall, frame)
        if len(endpoint_entries) >= 2:
            width_boundaries.append(endpoint_entries)

        face_data = planar_face_reference_data(wall, view)
        face_width_entries = extreme_face_entries(
            face_data,
            frame,
            frame["right"],
        )
        if len(face_width_entries) >= 2:
            width_boundaries.append(face_width_entries)

        height_boundaries = []
        face_height_entries = extreme_face_entries(
            face_data,
            frame,
            frame["up"],
        )
        if len(face_height_entries) >= 2:
            height_boundaries.append(face_height_entries)

        vertical_grids, horizontal_grids = collect_grid_line_data(
            wall,
            frame,
        )

        if settings["dimension_grids"] and vertical_grids:
            width_grid_line = DB.Line.CreateBound(
                frame_point(frame, min_x, min_y - spacing),
                frame_point(frame, max_x, min_y - spacing),
            )
            variants = build_grid_entry_variants(
                vertical_grids,
                width_boundaries,
            )
            dimension, error = first_successful_dimension(
                view,
                width_grid_line,
                variants,
            )
            if dimension is not None:
                result["grid_dimensions"] += 1
            else:
                coordinates = [min_x]
                coordinates.extend(
                    item["coordinate"] for item in vertical_grids
                )
                coordinates.append(max_x)
                sequence = interval_text(coordinates)
                if sequence:
                    fallback_lines.append(
                        "WIDTH GRID: {0}".format(sequence)
                    )
                result["warnings"].append(
                    "Horizontal grid-chain dimension could not bind: {0}".format(error)
                )

        if settings["dimension_grids"] and horizontal_grids:
            height_grid_line = DB.Line.CreateBound(
                frame_point(frame, min_x - spacing, min_y),
                frame_point(frame, min_x - spacing, max_y),
            )
            variants = build_grid_entry_variants(
                horizontal_grids,
                height_boundaries,
            )
            dimension, error = first_successful_dimension(
                view,
                height_grid_line,
                variants,
            )
            if dimension is not None:
                result["grid_dimensions"] += 1
            else:
                coordinates = [min_y]
                coordinates.extend(
                    item["coordinate"] for item in horizontal_grids
                )
                coordinates.append(max_y)
                sequence = interval_text(coordinates)
                if sequence:
                    fallback_lines.append(
                        "HEIGHT GRID: {0}".format(sequence)
                    )
                result["warnings"].append(
                    "Vertical grid-chain dimension could not bind: {0}".format(error)
                )

        if settings["dimension_overall"]:
            width_dimension_line = DB.Line.CreateBound(
                frame_point(frame, min_x, min_y - (2.0 * spacing)),
                frame_point(frame, max_x, min_y - (2.0 * spacing)),
            )
            dimension, error = first_successful_dimension(
                view,
                width_dimension_line,
                width_boundaries,
            )
            if dimension is not None:
                result["overall_dimensions"] += 1
            else:
                fallback_lines.append(
                    "OVERALL WIDTH: {0}".format(format_length(width))
                )
                result["warnings"].append(
                    "Overall width dimension could not bind: {0}".format(error)
                )

            height_dimension_line = DB.Line.CreateBound(
                frame_point(frame, min_x - (2.0 * spacing), min_y),
                frame_point(frame, min_x - (2.0 * spacing), max_y),
            )
            dimension, error = first_successful_dimension(
                view,
                height_dimension_line,
                height_boundaries,
            )
            if dimension is not None:
                result["overall_dimensions"] += 1
            else:
                fallback_lines.append(
                    "OVERALL HEIGHT: {0}".format(format_length(height))
                )
                result["warnings"].append(
                    "Overall height dimension could not bind: {0}".format(error)
                )

    if fallback_lines:
        note_point = frame_point(
            frame,
            min_x,
            max_y + (0.65 * spacing),
        )
        note, error = try_create_text_note(
            view,
            note_point,
            "\n".join(fallback_lines),
            text_type_id,
        )
        if note is not None:
            result["fallback_notes"] += 1
        else:
            result["warnings"].append(
                "Fallback annotation note could not be created: {0}".format(error)
            )

    return result


# -----------------------------------------------------------------------------
# Sheet layout
# -----------------------------------------------------------------------------

def viewport_footprints(viewports):
    """Measure each viewport, including its title label when available."""
    footprints = []
    for viewport in viewports:
        box_outline = viewport.GetBoxOutline()
        minimum_x = box_outline.MinimumPoint.X
        minimum_y = box_outline.MinimumPoint.Y
        maximum_x = box_outline.MaximumPoint.X
        maximum_y = box_outline.MaximumPoint.Y

        try:
            label_outline = viewport.GetLabelOutline()
            minimum_x = min(minimum_x, label_outline.MinimumPoint.X)
            minimum_y = min(minimum_y, label_outline.MinimumPoint.Y)
            maximum_x = max(maximum_x, label_outline.MaximumPoint.X)
            maximum_y = max(maximum_y, label_outline.MaximumPoint.Y)
        except Exception:
            pass

        box_center = viewport.GetBoxCenter()
        union_center_x = (minimum_x + maximum_x) / 2.0
        union_center_y = (minimum_y + maximum_y) / 2.0

        footprints.append(
            {
                "width": maximum_x - minimum_x,
                "height": maximum_y - minimum_y,
                "offset_x": union_center_x - box_center.X,
                "offset_y": union_center_y - box_center.Y,
            }
        )
    return footprints


def pack_footprints(footprints, left, right, bottom, top, gap):
    """Pack all viewport footprints into one page, largest first."""
    order = sorted(
        range(len(footprints)),
        key=lambda index: (
            -footprints[index]["height"],
            -footprints[index]["width"],
        ),
    )

    positions = [None] * len(footprints)
    x_position = left
    y_position = top
    row_height = 0.0

    for index in order:
        width = footprints[index]["width"]
        height = footprints[index]["height"]

        if width > (right - left) or height > (top - bottom):
            return None

        if x_position > left and x_position + width > right:
            x_position = left
            y_position -= row_height + gap
            row_height = 0.0

        if y_position - height < bottom:
            return None

        positions[index] = DB.XYZ(
            x_position + width / 2.0,
            y_position - height / 2.0,
            0.0,
        )
        x_position += width + gap
        row_height = max(row_height, height)

    return positions


def pack_footprints_across_pages(
    footprints,
    left,
    right,
    bottom,
    top,
    gap,
):
    """Pack footprints into as many row-based pages as required."""
    order = sorted(
        range(len(footprints)),
        key=lambda index: (
            -footprints[index]["height"],
            -footprints[index]["width"],
        ),
    )

    page_width = right - left
    page_height = top - bottom
    for index in order:
        if (
            footprints[index]["width"] > page_width
            or footprints[index]["height"] > page_height
        ):
            return None

    pages = []
    current = None

    for index in order:
        width = footprints[index]["width"]
        height = footprints[index]["height"]

        if current is None:
            current = {
                "indices": [],
                "positions": {},
                "x": left,
                "y": top,
                "row_height": 0.0,
            }
            pages.append(current)

        x_position = current["x"]
        y_position = current["y"]
        row_height = current["row_height"]

        if x_position > left and x_position + width > right:
            x_position = left
            y_position -= row_height + gap
            row_height = 0.0

        if y_position - height < bottom:
            current = {
                "indices": [],
                "positions": {},
                "x": left,
                "y": top,
                "row_height": 0.0,
            }
            pages.append(current)
            x_position = left
            y_position = top
            row_height = 0.0

        current["indices"].append(index)
        current["positions"][index] = DB.XYZ(
            x_position + width / 2.0,
            y_position - height / 2.0,
            0.0,
        )
        current["x"] = x_position + width + gap
        current["y"] = y_position
        current["row_height"] = max(row_height, height)

    for page in pages:
        page.pop("x", None)
        page.pop("y", None)
        page.pop("row_height", None)

    return pages


def scale_candidates(start_scale, auto_fit):
    start_scale = max(1, int(start_scale))
    if not auto_fit:
        return [start_scale]

    result = [start_scale]
    for scale in STANDARD_DRAWING_SCALES:
        if scale > start_scale and scale not in result:
            result.append(scale)
    return result


def overflow_positions(footprints, left, right, top, gap):
    """Best-effort row placement when the views still do not fit."""
    positions = []
    x_position = left
    y_position = top
    row_height = 0.0

    for footprint in footprints:
        width = footprint["width"]
        height = footprint["height"]
        if x_position > left and x_position + width > right:
            x_position = left
            y_position -= row_height + gap
            row_height = 0.0
        positions.append(
            DB.XYZ(
                x_position + width / 2.0,
                y_position - height / 2.0,
                0.0,
            )
        )
        x_position += width + gap
        row_height = max(row_height, height)
    return positions


def oversized_pages(footprints, left, right, bottom, top):
    """Place each oversized viewport on its own centred page as a fallback."""
    centre = DB.XYZ(
        (left + right) / 2.0,
        (bottom + top) / 2.0,
        0.0,
    )
    pages = []
    for index in range(len(footprints)):
        pages.append(
            {
                "indices": [index],
                "positions": {index: centre},
            }
        )
    return pages


def target_box_centre(footprint, union_centre):
    return DB.XYZ(
        union_centre.X - footprint["offset_x"],
        union_centre.Y - footprint["offset_y"],
        0.0,
    )


# -----------------------------------------------------------------------------
# Revit creation routine
# -----------------------------------------------------------------------------

def activate_title_block(title_block):
    try:
        if isinstance(title_block, DB.FamilySymbol) and not title_block.IsActive:
            title_block.Activate()
            doc.Regenerate()
    except Exception:
        pass


def create_sheet(title_block, desired_number, sheet_name, used_numbers):
    sheet = DB.ViewSheet.Create(doc, title_block.Id)
    sheet.SheetNumber = reserve_unique_sheet_number(
        desired_number,
        used_numbers,
    )
    sheet.Name = sheet_name
    return sheet


def create_view_name(wall, naming_data, settings, used_names):
    if settings["name_by_type"]:
        data = naming_data[id_number(wall)]
        base_name = "CW ELEVATION - {0}".format(data["type_name"])
        if data["total"] > 1:
            base_name += " - {0:02d}".format(data["sequence"])
    else:
        base_name = "CW ELEVATION - ID {0}".format(id_number(wall))
    return unique_view_name(base_name, used_names)


def create_curtain_wall_sheets(walls, settings):
    title_block = settings["title_block"]
    section_type = settings["section_type"]
    start_scale = settings["start_scale"]
    requested_crop_margin = mm(settings["crop_margin_mm"])
    dimension_spacing = mm(settings["dimension_spacing_mm"])
    viewport_gap = mm(settings["viewport_gap_mm"])
    sheet_margin = mm(settings["sheet_margin_mm"])
    bottom_reserve = mm(settings["bottom_reserve_mm"])

    dimensions_requested = (
        settings["dimension_grids"] or settings["dimension_overall"]
    )
    effective_crop_margin = requested_crop_margin
    if dimensions_requested:
        effective_crop_margin = max(
            requested_crop_margin,
            dimension_spacing * 3.0,
        )

    depth_margin = max(effective_crop_margin, mm(500))
    text_type_id = collect_text_note_type_id()

    used_view_names = all_used_view_names()
    used_sheet_numbers = all_sheet_numbers()
    naming_data = view_name_data(walls)
    records = []
    failures = []
    dimension_warnings = []
    dimension_totals = {
        "overall_dimensions": 0,
        "grid_dimensions": 0,
        "fallback_notes": 0,
    }
    final_scale = start_scale
    fitted = False
    page_layouts = None
    footprints = None
    sheets = []
    created_viewports = []

    transaction = DB.Transaction(doc, "Create curtain wall elevation sheets")
    transaction.Start()

    try:
        activate_title_block(title_block)

        first_sheet = create_sheet(
            title_block,
            settings["sheet_number"],
            settings["sheet_name"],
            used_sheet_numbers,
        )
        sheets.append(first_sheet)
        doc.Regenerate()

        sheet_outline = first_sheet.Outline
        temporary_point = DB.XYZ(
            (sheet_outline.Min.U + sheet_outline.Max.U) / 2.0,
            (sheet_outline.Min.V + sheet_outline.Max.V) / 2.0,
            0.0,
        )

        for wall in walls:
            wall_subtransaction = DB.SubTransaction(doc)
            wall_subtransaction.Start()
            try:
                frame = curtain_wall_section_frame(
                    wall,
                    effective_crop_margin,
                    depth_margin,
                    settings["view_side"],
                )
                view = DB.ViewSection.CreateSection(
                    doc,
                    section_type.Id,
                    frame["box"],
                )
                view.Name = create_view_name(
                    wall,
                    naming_data,
                    settings,
                    used_view_names,
                )
                view.Scale = start_scale
                view.CropBoxActive = True
                view.CropBoxVisible = False
                try:
                    view.DetailLevel = DB.ViewDetailLevel.Fine
                except Exception:
                    pass

                viewport = DB.Viewport.Create(
                    doc,
                    first_sheet.Id,
                    view.Id,
                    temporary_point,
                )
                wall_subtransaction.Commit()

                record = {
                    "wall": wall,
                    "view": view,
                    "frame": frame,
                    "temporary_viewport": viewport,
                }
                records.append(record)

                try:
                    annotation_result = annotate_curtain_wall(
                        wall,
                        view,
                        frame,
                        settings,
                        text_type_id,
                    )
                    dimension_totals["overall_dimensions"] += (
                        annotation_result["overall_dimensions"]
                    )
                    dimension_totals["grid_dimensions"] += (
                        annotation_result["grid_dimensions"]
                    )
                    dimension_totals["fallback_notes"] += (
                        annotation_result["fallback_notes"]
                    )
                    if annotation_result["warnings"]:
                        dimension_warnings.append(
                            {
                                "element_id": wall.Id,
                                "wall_id": id_number(wall),
                                "wall_type": element_type_name(wall.WallType),
                                "warning": " | ".join(
                                    annotation_result["warnings"]
                                ),
                            }
                        )
                except Exception as annotation_error:
                    dimension_warnings.append(
                        {
                            "element_id": wall.Id,
                            "wall_id": id_number(wall),
                            "wall_type": element_type_name(wall.WallType),
                            "warning": (
                                "Dimensioning failed, but the view was retained: {0}"
                                .format(annotation_error)
                            ),
                        }
                    )

            except Exception as error:
                try:
                    wall_subtransaction.RollBack()
                except Exception:
                    pass
                failures.append(
                    {
                        "element_id": wall.Id,
                        "wall_id": id_number(wall),
                        "wall_type": element_type_name(wall.WallType),
                        "error": str(error),
                    }
                )

        if not records:
            raise RuntimeError("No curtain-wall views could be created.")

        doc.Regenerate()

        sheet_outline = first_sheet.Outline
        left = sheet_outline.Min.U + sheet_margin
        right = sheet_outline.Max.U - sheet_margin
        bottom = sheet_outline.Min.V + bottom_reserve
        top = sheet_outline.Max.V - sheet_margin

        if right <= left or top <= bottom:
            raise RuntimeError(
                "The selected sheet is too small for the entered sheet margins."
            )

        temporary_viewports = [
            record["temporary_viewport"] for record in records
        ]

        for candidate_scale in scale_candidates(
            start_scale,
            settings["auto_fit"],
        ):
            for record in records:
                record["view"].Scale = candidate_scale
            doc.Regenerate()

            footprints = viewport_footprints(temporary_viewports)
            final_scale = candidate_scale

            if settings["multiple_sheets"]:
                page_layouts = pack_footprints_across_pages(
                    footprints,
                    left,
                    right,
                    bottom,
                    top,
                    viewport_gap,
                )
                if page_layouts is not None:
                    fitted = True
                    break
            else:
                positions = pack_footprints(
                    footprints,
                    left,
                    right,
                    bottom,
                    top,
                    viewport_gap,
                )
                if positions is not None:
                    page_layouts = [
                        {
                            "indices": list(range(len(records))),
                            "positions": dict(
                                (index, positions[index])
                                for index in range(len(records))
                            ),
                        }
                    ]
                    fitted = True
                    break

        if footprints is None:
            footprints = viewport_footprints(temporary_viewports)

        if page_layouts is None:
            if settings["multiple_sheets"]:
                page_layouts = oversized_pages(
                    footprints,
                    left,
                    right,
                    bottom,
                    top,
                )
            else:
                positions = overflow_positions(
                    footprints,
                    left,
                    right,
                    top,
                    viewport_gap,
                )
                page_layouts = [
                    {
                        "indices": list(range(len(records))),
                        "positions": dict(
                            (index, positions[index])
                            for index in range(len(records))
                        ),
                    }
                ]

        for viewport in temporary_viewports:
            doc.Delete(viewport.Id)
        doc.Regenerate()

        total_pages = len(page_layouts)
        for page_index in range(1, total_pages):
            desired_number = sheet_series_candidate(
                settings["sheet_number"],
                page_index,
            )
            sheet = create_sheet(
                title_block,
                desired_number,
                settings["sheet_name"],
                used_sheet_numbers,
            )
            sheets.append(sheet)

        if total_pages > 1:
            for page_index, sheet in enumerate(sheets):
                sheet.Name = "{0} - {1} OF {2}".format(
                    settings["sheet_name"],
                    page_index + 1,
                    total_pages,
                )
        else:
            first_sheet.Name = settings["sheet_name"]

        views_per_sheet = []
        for page_index, page in enumerate(page_layouts):
            sheet = sheets[page_index]
            page_viewports = []

            for record_index in page["indices"]:
                record = records[record_index]
                union_centre = page["positions"][record_index]
                box_centre = target_box_centre(
                    footprints[record_index],
                    union_centre,
                )
                viewport = DB.Viewport.Create(
                    doc,
                    sheet.Id,
                    record["view"].Id,
                    box_centre,
                )
                page_viewports.append(viewport)
                created_viewports.append(viewport)
                record["sheet"] = sheet
                record["viewport"] = viewport

            views_per_sheet.append(len(page_viewports))

        doc.Regenerate()
        transaction.Commit()

        return {
            "sheets": sheets,
            "sheet_numbers": [sheet.SheetNumber for sheet in sheets],
            "sheet_names": [sheet.Name for sheet in sheets],
            "views_per_sheet": views_per_sheet,
            "walls_found": len(walls),
            "views_created": [record["view"] for record in records],
            "viewports_created": created_viewports,
            "requested_scale": start_scale,
            "final_scale": final_scale,
            "fitted": fitted,
            "failures": failures,
            "dimension_warnings": dimension_warnings,
            "dimension_totals": dimension_totals,
            "multiple_sheets_enabled": settings["multiple_sheets"],
        }

    except Exception:
        try:
            transaction.RollBack()
        except Exception:
            pass
        raise


# -----------------------------------------------------------------------------
# Results and command entry point
# -----------------------------------------------------------------------------

def linked_element(element_id, fallback):
    try:
        return output.linkify(element_id)
    except Exception:
        return str(fallback)


def show_result(result):
    output.set_title("Curtain Wall Elevation Sheets")
    output.print_md("# Curtain Wall Elevation Sheets Created")

    sheet_rows = []
    for index, sheet in enumerate(result["sheets"]):
        sheet_rows.append(
            [
                linked_element(sheet.Id, id_number(sheet)),
                sheet.SheetNumber,
                sheet.Name,
                result["views_per_sheet"][index],
            ]
        )
    output.print_table(
        table_data=sheet_rows,
        columns=["Sheet", "Number", "Name", "Views"],
        title="Created Sheets",
    )

    dimensions = result["dimension_totals"]
    summary_rows = [
        ["Curtain walls found", result["walls_found"]],
        ["Views created", len(result["views_created"])],
        ["Sheets created", len(result["sheets"])],
        ["Selected drawing scale", "1:{0}".format(result["requested_scale"])],
        ["Final view scale", "1:{0}".format(result["final_scale"])],
        ["All viewports fit calculated sheet areas", result["fitted"]],
        ["Curtain-grid dimensions created", dimensions["grid_dimensions"]],
        ["Overall dimensions created", dimensions["overall_dimensions"]],
        ["Fallback value notes created", dimensions["fallback_notes"]],
        ["Walls skipped", len(result["failures"])],
    ]
    output.print_table(
        table_data=summary_rows,
        columns=["Result", "Value"],
        title="Run Summary",
    )

    if result["dimension_warnings"]:
        warning_rows = []
        for warning in result["dimension_warnings"]:
            warning_rows.append(
                [
                    linked_element(
                        warning["element_id"],
                        warning["wall_id"],
                    ),
                    warning["wall_type"],
                    warning["warning"],
                ]
            )
        output.print_table(
            table_data=warning_rows,
            columns=["Curtain Wall", "Wall Type", "Dimension Note"],
            title="Dimensioning Review",
        )

    if result["failures"]:
        failure_rows = []
        for failure in result["failures"]:
            failure_rows.append(
                [
                    linked_element(
                        failure["element_id"],
                        failure["wall_id"],
                    ),
                    failure["wall_type"],
                    failure["error"],
                ]
            )
        output.print_table(
            table_data=failure_rows,
            columns=["Curtain Wall", "Wall Type", "Reason Skipped"],
            title="Skipped Curtain Walls",
        )

    if result["fitted"]:
        fit_message = (
            "All viewports fit within the calculated sheet areas."
        )
    else:
        fit_message = (
            "One or more viewports remained larger than the calculated sheet "
            "area after the available scale attempts. Review the generated "
            "sheets, use a larger title block, or increase the scale denominator."
        )

    message = (
        "Created {0} curtain-wall view{1} on {2} sheet{3} at 1:{4}.\n\n{5}"
        .format(
            len(result["views_created"]),
            "" if len(result["views_created"]) == 1 else "s",
            len(result["sheets"]),
            "" if len(result["sheets"]) == 1 else "s",
            result["final_scale"],
            fit_message,
        )
    )

    if result["final_scale"] != result["requested_scale"]:
        message += (
            "\n\nSelected scale 1:{0} was automatically adjusted to 1:{1} "
            "because at least one viewport was too large for the sheet."
            .format(result["requested_scale"], result["final_scale"])
        )

    if result["dimension_warnings"]:
        message += (
            "\n\n{0} curtain-wall view{1} require dimension review; "
            "see the pyRevit output."
            .format(
                len(result["dimension_warnings"]),
                "" if len(result["dimension_warnings"]) == 1 else "s",
            )
        )

    if result["failures"]:
        message += "\n\n{0} wall{1} were skipped.".format(
            len(result["failures"]),
            "" if len(result["failures"]) == 1 else "s",
        )

    forms.alert(
        message,
        title="Curtain Wall Sheets",
        warn_icon=(
            not result["fitted"]
            or bool(result["failures"])
            or bool(result["dimension_warnings"])
        ),
    )


def main():
    if doc is None:
        forms.alert(
            "Open a Revit project before running this command.",
            title="Curtain Wall Sheets",
            warn_icon=True,
        )
        return

    if doc.IsFamilyDocument:
        forms.alert(
            "Run this command in a Revit project, not in the Family Editor.",
            title="Curtain Wall Sheets",
            warn_icon=True,
        )
        return

    walls = collect_curtain_walls()
    if not walls:
        forms.alert(
            "No curtain-wall Wall instances were found in the active project.\n\n"
            "The command does not process linked models or mass-based "
            "CurtainSystem elements.",
            title="Curtain Wall Sheets",
            warn_icon=True,
        )
        return

    title_blocks = collect_title_blocks()
    if not title_blocks:
        forms.alert(
            "No title-block type is loaded in this project.",
            title="Curtain Wall Sheets",
            warn_icon=True,
        )
        return

    section_types = collect_section_types()
    if not section_types:
        forms.alert(
            "No Section ViewFamilyType is available in this project.",
            title="Curtain Wall Sheets",
            warn_icon=True,
        )
        return

    dialog = CurtainWallSettingsWindow(
        title_blocks,
        section_types,
        len(walls),
    )
    dialog.show_dialog()
    settings = dialog.result
    if not settings:
        return

    save_settings(settings)

    try:
        result = create_curtain_wall_sheets(walls, settings)
        if settings["open_sheet"] and result["sheets"]:
            try:
                uidoc.ActiveView = result["sheets"][0]
            except Exception:
                try:
                    uidoc.RequestViewChange(result["sheets"][0])
                except Exception:
                    pass
        show_result(result)
    except Exception as error:
        error_traceback = traceback.format_exc()
        logger.error(error_traceback)
        output.set_title("Curtain Wall Elevation Sheets - Error")
        output.print_md("# Curtain Wall Sheets Failed")
        output.print_md("**Error:** {0}".format(str(error)))
        output.print_md("```text\n{0}\n```".format(error_traceback))
        forms.alert(
            "The operation failed and the Revit transaction was rolled back.\n\n"
            "{0}\n\nSee the pyRevit output for the full traceback."
            .format(str(error)),
            title="Curtain Wall Sheets",
            warn_icon=True,
        )


main()
