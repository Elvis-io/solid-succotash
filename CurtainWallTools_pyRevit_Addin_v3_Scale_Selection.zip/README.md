# Curtain Wall Tools — pyRevit Extension

This pyRevit command finds curtain-wall `Wall` instances in the active Revit project, creates one wall-aligned orthographic section/elevation for each instance, documents the views, and arranges them on one or more sheets.

## New in this version

- An explicit **Drawing scale** selector provides standard architectural ratios such as `1:20`, `1:25`, `1:50`, `1:75`, `1:100`, and `1:200`. The selector is editable, so a custom whole-number denominator such as `1:40` or `1:60` can also be entered.
- The selected scale is applied to every generated curtain-wall view before the sheet layout is calculated.
- When continuation sheets are enabled, the command keeps the selected scale and creates more sheets as required. It only changes to a smaller drawing size when a single viewport cannot fit and **Auto-adjust** is enabled.
- View names are based on the curtain wall **type**, with a sequence number when more than one instance uses the same type.
- Optional chained dimensions are added to the curtain grid lines.
- Optional overall curtain wall **width and height** dimensions are added.
- When a curtain wall cannot provide valid dimension references, the view is retained and a formatted value note plus a review warning is produced.
- Overflow views can be placed automatically on continuation sheets rather than being forced onto one crowded sheet.
- Continuation numbers are generated as a series. For example, a first number of `CW-001` produces `CW-001`, `CW-002`, `CW-003`, subject to uniqueness in the project.

## Requirements

- Autodesk Revit 2022–2026
- A pyRevit installation compatible with the installed Revit version
- At least one loaded Revit title-block type
- At least one Section view type
- A Revit project document; the command does not run in the Family Editor

The command uses pyRevit's default IronPython engine because the settings window is built with pyRevit WPF forms. Do not add a CPython/Python 3 shebang to `script.py`.

## Installation

### Automatic installation

1. Extract the ZIP package to a normal Windows folder.
2. Double-click `Install_CurtainWallTools.bat`.
3. Open Revit and use **pyRevit > Reload**, or restart Revit.

The installer copies the extension to:

```text
%APPDATA%\pyRevit\Extensions\CurtainWallTools.extension
```

The installer uses `/PURGE`, so installing this package over an older version replaces the old command files.

### Manual installation

Copy the entire folder:

```text
CurtainWallTools.extension
```

to:

```text
%APPDATA%\pyRevit\Extensions\
```

The final path should be:

```text
%APPDATA%\pyRevit\Extensions\CurtainWallTools.extension
```

Reload pyRevit or restart Revit.

## Ribbon location

```text
Curtain Wall Tools > Documentation > Curtain Wall Sheets
```

## How to use

1. Open the Revit project containing the curtain walls and save a backup.
2. Open **Curtain Wall Tools > Documentation > Curtain Wall Sheets**.
3. Select the title block, Section view type, and wall face.
4. Enter the first sheet number and base sheet name.
5. Select the required **Drawing scale**. Choose a listed ratio or type a custom value in the scale field. Accepted examples include `50`, `1:50`, and `1/50`.
6. Leave **Name each view using its curtain wall type** enabled to produce names such as:

```text
CW ELEVATION - Exterior Glazed Wall - 01
CW ELEVATION - Exterior Glazed Wall - 02
CW ELEVATION - Storefront
```

7. Enable the required documentation options:
   - **Add chained dimensions to curtain grid lines**
   - **Add overall curtain wall width and height dimensions**
8. Set the dimension line spacing. The command automatically enlarges the view crop margin when the dimensions need more room.
9. Leave **Place overflow views on continuation sheets** enabled when the first sheet may become crowded.
10. Leave **Auto-adjust to a smaller drawing size only when a viewport is too large** enabled when the command may change from, for example, `1:50` to `1:75` to fit an oversized individual view. Disable it to lock every generated view to the selected scale.
11. Click **Create Views + Sheets**.

## Multi-sheet behaviour

At the selected drawing scale, the command measures each viewport, including its title where supported by the installed Revit API. It packs the largest viewports first. When all views do not fit on the first sheet, it creates continuation sheets and distributes the remaining views without changing the selected scale.

If one individual viewport is larger than the usable sheet area, the **Auto-adjust** option tries progressively larger scale denominators until that viewport fits. Turning Auto-adjust off locks the selected scale; an oversized viewport is then placed as a best-effort result and reported for review.

For a base sheet number of:

```text
CW-001
```

the normal sequence is:

```text
CW-001
CW-002
CW-003
```

If a proposed number already exists, a unique suffix is added. Sheet names are identified as a set, for example:

```text
CURTAIN WALL ELEVATIONS - 1 OF 3
CURTAIN WALL ELEVATIONS - 2 OF 3
CURTAIN WALL ELEVATIONS - 3 OF 3
```

Disable the continuation-sheet option to retain the earlier one-sheet behaviour. The command will then try progressively higher scale denominators before using a best-effort overflow layout.

## Dimension behaviour

The command attempts to create native Revit linear dimensions with geometric references:

- Vertical curtain grid lines are used for the horizontal grid chain.
- Horizontal curtain grid lines are used for the vertical grid chain.
- Wall endpoints and extreme model faces are used for overall width and height.
- The current Revit default linear dimension style is used.

Revit geometry varies between curtain wall families and project configurations. If valid references cannot be bound, the script keeps the view, adds a value note where possible, and lists the affected wall in the pyRevit output under **Dimensioning Review**. Curved curtain walls receive projected overall values and require manual review for developed or radial dimensions.

## Result report

The pyRevit output lists:

- All created sheets and the number of views on each
- Selected drawing scale
- Final view scale, including whether Auto-adjust changed it
- Grid dimensions created
- Overall dimensions created
- Fallback value notes created
- Dimensioning warnings requiring review
- Curtain walls skipped because a view could not be created

## Scope and limitations

- Processes curtain-wall `Wall` instances in the active project only.
- Does not process Revit links.
- Does not process mass-based `CurtainSystem` elements.
- Curved curtain walls are orthographically projected; they are not developed or unrolled.
- Every execution creates a new set of views and sheets. It does not update a previous run.
- Generated section/elevation references may be visible in applicable model views, depending on project visibility settings.
- Native dimensions depend on usable Revit geometric references. Review the **Dimensioning Review** table after each run.

## Uninstallation

Double-click:

```text
Uninstall_CurtainWallTools.bat
```

Then reload pyRevit or restart Revit.

## Package structure

```text
CurtainWallTools.extension/
└── Curtain Wall Tools.tab/
    └── Documentation.panel/
        └── Create Curtain Wall Sheet.pushbutton/
            ├── bundle.yaml
            ├── icon.png
            ├── icon.dark.png
            ├── script.py
            └── ui.xaml
```

## Validation status

The package has been checked for Python syntax, drawing-scale parsing, scale-candidate ordering, XAML/XML validity, expected command files, WPF control/event matching, and archive integrity. Static validation cannot reproduce Revit's model-specific geometric references, so the first run should be made on a copy of the project and all generated dimensions should be reviewed before issue.
